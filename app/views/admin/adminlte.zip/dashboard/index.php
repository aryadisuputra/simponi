<?php view('admin/partial/header', $data) ?>
	<section class="content-header">
	  	<h1>
			Dashboard
			<!-- <small>Optional description</small> -->
	  	</h1>
	  	<ol class="breadcrumb">
			<!-- <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li class="active">Here</li> -->
			<li class="active"><i class="fa fa-dashboard"></i> Dashboard</a></li>
	  	</ol>
	</section>

	<section class="content container-fluid">
		<!-- disini taruh kontennya anjing  -->
	</section>
<?php view('admin/partial/footer', $data) ?>